<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Login or Register with Kotak Net Banking</name>
   <tag></tag>
   <elementGuidId>05bee7fa-1f30-44a4-afdc-9ce045d0e5a1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1.check</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Send Money Abroad'])[2]/preceding::h1[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>fdd09d6c-f913-49fd-a029-b53478bb7d9f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>check</value>
      <webElementGuid>b6380c54-2e03-4be2-a417-528d70af9259</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Login or Register with Kotak Net Banking </value>
      <webElementGuid>8dbe1b44-085f-4571-bf1b-8870b7f01061</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/div[1]/app-login[@class=&quot;ng-tns-c2-0 ng-star-inserted&quot;]/div[@class=&quot;form-body&quot;]/div[@class=&quot;form-holder&quot;]/div[@class=&quot;form-content&quot;]/div[@class=&quot;form-items&quot;]/div[@class=&quot;Routerbox ng-trigger ng-trigger-fadeAnimation&quot;]/app-crn-card-nick[@class=&quot;ng-star-inserted&quot;]/app-card-layout[1]/div[@class=&quot;htmlContent crnbasepaddRigh1 align-crn-box&quot;]/h1[@class=&quot;check&quot;]</value>
      <webElementGuid>6d64936d-5a48-454d-9b76-5ea798e94c65</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Send Money Abroad'])[2]/preceding::h1[1]</value>
      <webElementGuid>7a7e2980-ddff-4f43-8385-c6e12d678b88</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your CRN, Username or Card Number to begin'])[1]/preceding::h1[1]</value>
      <webElementGuid>d3cc364b-eb9f-462c-9769-db226f902ad8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Login or Register with Kotak Net Banking']/parent::*</value>
      <webElementGuid>40e1d879-664a-4340-af2d-5eacbe21ba5b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>e9c79aff-bd32-4af0-a166-1a9bba2095a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = ' Login or Register with Kotak Net Banking ' or . = ' Login or Register with Kotak Net Banking ')]</value>
      <webElementGuid>ee3081fa-475f-43ee-93b5-c25d967a7a3f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
